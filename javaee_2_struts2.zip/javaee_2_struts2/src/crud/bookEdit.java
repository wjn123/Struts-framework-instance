package crud;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.opensymphony.xwork2.ActionSupport;
@SuppressWarnings("serial")
public class bookEdit extends ActionSupport{

	String name;
	String id;
	String msg;
	
	
	public String getMsg() {
		return msg;
	}



	public void setMsg(String msg) {
		this.msg = msg;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}


	@Override
	public String execute() throws Exception
	{
		// ��������
		Connection con = null;    
		Statement stmt = null;    
		
		String db_url = "jdbc:mysql://localhost:3306/stu?useUnicode=true&characterEncoding=utf8";
		String db_user = "root";
		String db_pass = "123456789";
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver"); 
			con = DriverManager.getConnection(db_url, db_user, db_pass);  
			
			String strSql = "update book set Name='" + getName() + "' where ID='" + getId() + "'";    
			stmt = con.createStatement();  
			stmt.execute(strSql);
		}
		catch (Exception e) 
		{
			setMsg("id�ظ�!");
			return "Error";
		}
		
		return "Success";
		
	}

}

