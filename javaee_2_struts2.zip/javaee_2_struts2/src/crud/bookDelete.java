package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.http.HttpServletRequest;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class bookDelete  extends ActionSupport{

	String id;
	String msg;
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
	@Override
	public String execute() throws Exception
	{
		// ��������
		Connection con = null;    
		Statement stmt = null;    
		
		String db_url = "jdbc:mysql://localhost:3306/stu?useUnicode=true&characterEncoding=utf8";
		String db_user = "root";
		String db_pass = "123456789";
		try
		{
			Class.forName("com.mysql.jdbc.Driver"); 
			con = DriverManager.getConnection(db_url, db_user, db_pass);  
			
			String strSql = "delete from book where id = '" + getId() + "'";    
			stmt = con.createStatement();  
			stmt.execute(strSql);
		}
		catch (Exception e) 
		{
			setMsg("id�ظ�!");
			return "Error";
		}
		
		return "Success";
	}
}
